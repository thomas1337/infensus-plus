local infplus, C, L, _ = unpack(select(2, ...))
if infplus.locale ~= "deDE" then return end

-----------------------------
--	deDE client
-----------------------------
-- main frame
L.test		= "Test"
